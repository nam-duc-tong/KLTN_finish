<?php
    $active = 'home';
    include("includes/header.php");
?>
   
   <div class="container" id="slider" style="margin-bottom: 40px;"><!-- container Begin -->
       
       <div class="col-md-12"><!-- col-md-12 Begin -->
           
           <div class="carousel slide" id="myCarousel" data-ride="carousel"><!-- carousel slide Begin -->
               
               <ol class="carousel-indicators"><!-- carousel-indicators Begin -->
                   
                   <li class="active" data-target="#myCarousel" data-slide-to="0"></li>
                   <li data-target="#myCarousel" data-slide-to="1"></li>
                   <li data-target="#myCarousel" data-slide-to="2"></li>
                   <li data-target="#myCarousel" data-slide-to="3"></li>
                   
               </ol><!-- carousel-indicators Finish -->
               
               <div class="carousel-inner"><!-- carousel-inner Begin -->
                   
                   <?php
                        $get_slides = "select * from slider LIMIT 0,1";
                        $run_slider = mysqli_query($con,$get_slides);
                        while($row_slides = mysqli_fetch_array($run_slider))
                        {
                            $slide_name = $row_slides['slider_name'];
                            $slide_image = $row_slides['slider_image'];
                            $slide_url = $row_slides['slider_url'];
                            echo "
                                <div class='item active'>
                       
                                    <a href='$slide_url'>
                                        <img src='admin_area/slides_images/$slide_image'>
                                    </a>
                            
                                </div>
                            ";
                        }

                        $get_slides = "select * from slider LIMIT 1,3";
                        $run_slider = mysqli_query($con,$get_slides);
                        while($row_slides = mysqli_fetch_array($run_slider))
                        {
                            $slide_name = $row_slides['slider_name'];
                            $slide_image = $row_slides['slider_image'];
                            $slide_url = $row_slides['slider_url'];
                            echo "
                                <div class='item'>
                       
                                    <a href='$slide_url'>
                                        <img src='admin_area/slides_images/$slide_image'>
                                    </a>
                            
                                </div>
                            ";
                        }
                   ?>
                   
               </div><!-- carousel-inner Finish -->
               
               <a href="#myCarousel" class="left carousel-control" data-slide="prev"><!-- left carousel-control Begin -->
                   
                   <span class="glyphicon glyphicon-chevron-left"></span>
                   <span class="sr-only">Previous</span>
                   
               </a><!-- left carousel-control Finish -->
               
               <a href="#myCarousel" class="right carousel-control" data-slide="next"><!-- left carousel-control Begin -->
                   
                   <span class="glyphicon glyphicon-chevron-right"></span>
                   <span class="sr-only">Next</span>
                   
               </a><!-- left carousel-control Finish -->
               
           </div><!-- carousel slide Finish -->
           
       </div><!-- col-md-12 Finish -->
       
   </div><!-- container Finish -->
   <div id="advantages"> <!-- advantages begin -->

        <div class="container"><!-- container begin -->

            <div class="same-height-row"><!-- same-height-row begin -->

            <?php
                $get_boxes = "select * from boxes_section";

                $run_boxes = mysqli_query($con,$get_boxes);

                while($run_boxes_section = mysqli_fetch_array($run_boxes))
                {
                    $box_id = $run_boxes_section['box_id'];

                    $box_title = $run_boxes_section['box_title'];

                    $box_desc = $run_boxes_section['box_desc'];
                
            ?>

                <div class="col-sm-4"><!-- col-sm-4 begin -->
                    <div class="box same-height"><!-- box same-height begin -->
                        <div class="icon"><!-- icon begin -->
                            <i class='bx bxs-heart'style="font-size: 110px;padding-left: 135px;;" ></i>
                        </div><!-- icon finish -->
                    <h3><a href="#"><?php echo $box_title;?></a></h3>
                    <p><?php echo $box_desc;?></p>
                    </div><!-- box same-height finish -->

                </div><!-- col-sm-4 finish -->
                
                <?php
                    }
                ?>
               
            </div><!-- same-height-row  finish -->

        </div><!-- container finish -->

   </div><!-- advantages finish -->
    
    <div id="hot"> <!-- hot begin -->

        <div class="box"> <!-- box begin -->

            <div class="container"><!-- container begin -->

                <div class="col-md-12"> <!-- col-md-12 begin -->
                    <h2>Danh Sách Sản Phẩm</h2>
                </div><!-- col-md-12 begin -->

            </div><!-- container begin -->
            
        </div> <!-- box begin -->

    </div> <!-- hot begin -->
    <div id="content" class="container"><!-- container begin -->
        <div class="row"><!-- row begin -->
           <?php

                getPro();

           ?>
        </div><!-- row finish -->
    </div><!-- container finish -->

    <?php
        include("includes/footer.php");
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>