<?php
session_start();
include("includes/db.php");
include("functions/functions.php");
?>
<?php
if (isset($_GET['c_id'])) {
    $customer_id = $_GET['c_id'];
}

$ip_add = getRealIpUser();

$status = 0;//chơ xác nhận

$invoice_no = mt_rand(); //ham tao ra cac gia tri ngau nhien

$select_cart = "select * from cart where ip_add = '$ip_add'";

$run_cart = mysqli_query($con, $select_cart);

$total_order = 0;

$order_detail_array = array();

while ($row_cart = mysqli_fetch_array($run_cart)) //lay tung cai mot trong gio hang
{
    $pro_id = $row_cart['p_id'];

    $pro_qty = $row_cart['qty'];

    $pro_size = $row_cart['size'];

    $result = mysqli_query($con, "select product_price from product where product_id = '$pro_id'");

    $product = mysqli_fetch_assoc($result);

    $pro_price = $product['product_price'];

    $sub_total = $pro_price * $pro_qty;

    $total_order += $sub_total;

    $orderDetail = array(
        "pro_id" => $pro_id,
        "pro_qty" => $pro_qty,
        "pro_price" => $pro_price,
    );

    array_push($order_detail_array, $orderDetail);
}
$insert_order = "insert into orders(customer_id,total_order,invoice_no,order_status,order_date) values ('$customer_id','$total_order','$invoice_no','$status',NOW())";
$insert_order_p = mysqli_query($con, $insert_order);
$order_id_insert = mysqli_insert_id($con);

foreach ($order_detail_array as $x) {
    $pro_id = $x["pro_id"];
    $pro_qty = $x["pro_qty"];
    $pro_price = $x["pro_price"];
    $insert_order_detail = "insert into order_detail(product_id,order_id,quantity,price,size) values ('$pro_id','$order_id_insert','$pro_qty','$pro_price','$pro_size')";
    mysqli_query($con, $insert_order_detail);
}


$delete_cart = "delete from cart where ip_add = '$ip_add'";

$run_delete = mysqli_query($con, $delete_cart);

echo "
            <script> alert('Đặt Hàng Thành Công, Cảm ơn bạn đã mua hàng!!!')</script>
    ";

echo "
            <script>window.open('customer/my_account.php?my_orders','_self')</script>
        ";
?>