<div class="box">
    <?php
        $session_email = $_SESSION['customer_email'];

        $select_customer = "select * from customers where customer_email = '$session_email'";

        $run_customer = mysqli_query($con,$select_customer);

        $row_customer = mysqli_fetch_array($run_customer);

        $customer_id = $row_customer['customer_id'];

    ?>
    <h1 class="text-center" >
        Lựa Chọn Phương Thức Thanh Toán
    </h1>
    <p class="lead text-center">
        <a href="order.php?c_id=<?php echo $customer_id; ?>" class="" style="text-decoration: none;">Thanh Toán Trực Tiếp</a>
    </p>
    <center>
        <p class="lead">
            <div class="text-center">
                <button class="btn btn-primary btn-lg" name="confirm_payment">
                    <a href="http://localhost/KLTN/NamFashion/cart.php" style="color: #fff;"><img src="images/point.png" alt="" style="width:24px; height:auto;"> Quay lại</a>
                </button>
            </div>
        </p>
    </center>
</div>