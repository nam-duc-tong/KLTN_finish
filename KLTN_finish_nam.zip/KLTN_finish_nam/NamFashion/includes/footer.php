<div id="footer"> <!-- #footer begin -->
    <div class="container"> <!-- #container begin -->
        <div class="row"> <!-- #row begin -->
            <div class="col-sm-6 col-md-3"> <!-- #col-sm-6 col-md-3 begin -->
                
            <h4>Trang</h4>

                <ul><!-- #ul begin -->
                    <li><a href="cart.php">Giỏ Hàng</a></li><!-- #ul begin -->
                    <li><a href="contact.php">Liên Hệ</a></li>
                    <li><a href="shop.php">Cửa Hàng</a></li>
                    <li>
                            <a href="customer/my_account.php">Tài Khoản</a>
                    </li>
                </ul><!-- #ul finish -->
                <hr>

                <h4>Người dùng</h4>

                <ul><!-- #ul begin -->
                    <li>
                    <?php
                        if(!isset($_SESSION['customer_email']))
                        {
                            echo "<a href='checkout.php'>Login</a>";
                        }
                        else{
                            echo "<a href='customer/my_account.php?my_orders'>Tài Khoản</a>";
                        }
                    ?>
                    </li>
                    <li><a href="customer_register.php">Đăng Kí</a></li>
                </ul><!-- #ul finish -->

                <hr class="hidden-md hidden-lg hidden-sm">

            </div><!-- #col-sm-6 col-md-3 finish -->

            <div class="col-sm-6 col-md-3"><!-- #col-sm-6 col-md-3 begin -->

                <h4>Các danh mục sản phẩm</h4>
                <ul><!-- #ul begin -->
                    <!-- <li><a href="#">Jackets</a></li>
                    <li><a href="#">Accessories</a></li>
                    <li><a href="#">Coats</a></li>
                    <li><a href="#">Shoes</a></li>
                    <li><a href="#">T-Shirts</a></li> -->
                    <?php
                        $get_p_cats = "select * from product_categories";
                        $run_p_cats = mysqli_query($con,$get_p_cats);
                        while($row_p_cats = mysqli_fetch_array($run_p_cats))
                        {
                            $p_cat_id = $row_p_cats['p_cat_id'];
                            $p_cat_title = $row_p_cats['p_cat_title'];
                            echo "
                                <li>
                                    <a href='shop.php?p_cat=$p_cat_id'>
                                        $p_cat_title
                                    </a>
                                </li>
                            ";
                        } 
                    ?>
                </ul><!-- #ul finish -->

                <hr class="hidden-md hidden-lg">
            
            </div> <!-- #col-sm-6 col-md-3 finish -->
            
            <div class="col-sm-6 col-md-3"><!-- #col-sm-6 col-md-3 begin -->

                <h4>Thông tin chúng tôi: </h4>
                <p> <!-- p begin -->
                    <strong>Nam Fashion.</strong>
                    <br/> Ha Noi
                    <br> Viet Nam
                    <br>0968048046
                    <br>nam2382000@gmail.com
                    <br><strong>Nam Fashion</strong></br>
                </p><!-- p finish -->

                <a href="contact.php">Liên hệ đến chúng tôi</a>

                <hr class="hidden-md hidden-lg">

            </div> <!-- #col-sm-6 col-md-3 finish -->

             
            <div class="col-sm-6 col-md-3"><!-- #col-sm-6 col-md-3 begin -->

                <h4>Tạo tài khoản mới</h4>
                <p class="text-muted"> <!-- p begin -->
                    Bạn muốn tạo tài khoản mới?
                </p><!-- p finish -->

                <form action="" method="post"> <!-- form begin -->
                    <div class="input-group"> <!-- input-group begin -->
                        <input type="text" class="form-control" name="email"> <!-- form-control begin -->
                        <span class="input-group-btn"><!-- input-group-btn begin -->
                           <a href="customer_register.php"><input type="submit" value="subscribe" class="btn btn-default"></a>
                        </span><!-- input-group-btn finish -->
                    </div><!-- input-group finish -->
                </form><!-- form finish -->
                <hr>
                <h4>Giữ liên lạc</h4>
                <p class="social">
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter" ></a>
                    <a href="#" class="fa fa-instagram" ></a>
                    <a href="#" class="fa fa-google-plus" ></a>
                    <a href="#" class="fa fa-envelope" ></a>
                </p>
            </div> <!-- #col-sm-6 col-md-3 finish -->
        </div> <!-- #row finish -->
    </div><!-- #container finish --> 
</div><!-- #footer finish -->

<div id="copyright"> <!-- copy begin -->
    <div class="container"><!-- container begin -->
        <div class="col-md-6"><!-- #col-md-6 begin -->
            <p class="pull-left">&copy; Cửa Hàng Nam Fashion</p>
        </div><!-- col-md-6 finish -->

        <div class="col-md-6"><!-- #col-md-6 begin -->
            <p class="pull-right">Người thực hiện: <a href="customer/my_account.php?my_orders" class="pull-right-a"> Tống Đức Nam</p>
        </div><!-- col-md-6 finish -->
    </div><!-- container finish -->
</div><!-- copyright finish  -->