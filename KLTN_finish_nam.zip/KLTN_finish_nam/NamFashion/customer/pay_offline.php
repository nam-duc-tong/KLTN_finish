<center>
    <h1>
        Thanh Toán Trực Tiếp Cho Cửa Hàng
    </h1>
    <p class="text-muted">
        Nếu bạn có bất kì câu hỏi nào hãy <a href="../contact.php">Liên hệ chúng tôi</a>.Dịch vụ chăm sóc khách hàng của chúng tôi làm việc <strong>24/7</strong> 
    </p>
</center>
<hr>
<div class="table-reponsive">
    <table class="table table-bordered table-hover table-striped">
        <head>
            <tr>
               <th> Tài Khoản Ngân Hàng: </th>
               <th> Số Điện Thoại: </th>
               <th> Địa Chỉ: </th>
            </tr>
        </head>
        <tbody>
            <td> Tên Ngân Hàng: Vietinbank | Số Tài Khoản: 01234556789</td>
            <td> 06834789531</td>
            <td> Viet Nam</td>
        </tbody>
    </table>
</div>