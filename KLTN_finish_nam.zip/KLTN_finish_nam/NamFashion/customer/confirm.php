<?php
    session_start();
    $active='account';
    
    if(!isset($_SESSION['customer_email']))
    {
        echo "
            <script>window.open('../checkout.php','_self')</script>
        ";
    }
    else{
        include('includes/db.php');
        include('functions/functions.php');

    if(isset($_GET['order_id']))
    {
        $order_id = $_GET['order_id'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cửa hàng Nam Fashion</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/shop.css">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
 
  <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    
   <div id="top"><!-- Top Begin -->
       
       <div class="container"><!-- container Begin -->
           
           <div class="col-md-6"><!-- col-md-6 offer Begin -->
               
               <a href="#" class="btn btn-success btn-sm">
               <?php
                        if(!isset($_SESSION['customer_name']))
                        {
                            echo "Welcome: Khách hàng";
                        }
                        else{
                            echo "Welcome: ".$_SESSION['customer_name']."";
                        }
                   ?>
               </a>
               <a href="checkout.php" style="text-decoration: none;"><?php item();?> sản phẩm trong giỏ hàng | Tổng tiền: <?php total_price();?> </a>
               
           </div><!-- col-md-6 offer Finish -->
           
           <div class="col-md-6"><!-- col-md-6 Begin -->
               
               <ul class="menu"><!-- cmenu Begin -->
                   
                   <li>
                       <a href="../customer_register.php">Đăng Kí</a>
                   </li>
                   <li>
                       <a href="my_account.php">Tài Khoản</a>
                   </li>
                   <li>
                       <a href="../cart.php">Giỏ Hàng</a>
                   </li>
                   <li>
                       <a href="../checkout.php">
                       <?php
                            if(!isset($_SESSION['customer_email']))
                            {
                                echo "<a href='checkout.php'> Đăng Nhập </a>";
                            }
                            else{
                                echo "<a href='logout.php'> Đăng Xuất </a>";
                            }
                        ?>
                       </a>
                   </li>
                   
               </ul><!-- menu Finish -->
               
           </div><!-- col-md-6 Finish -->
           
       </div><!-- container Finish -->
       
   </div><!-- Top Finish -->
   
   <div id="navbar" class="navbar navbar-default"><!-- navbar navbar-default Begin -->
    
    <div class="container"><!-- container Begin -->
        
        <div class="navbar-header" style="width: 170px; padding-left: 14px;"><!-- navbar-header Begin -->
            
            <a href="../index.php" class="navbar-brand home"><!-- navbar-brand home Begin -->
                
                <img src="images/logo_big.png" alt="M-dev-Store Logo" class="hidden-xs" width="140px" height="auto">
                <img src="images/logo_small.png" alt="M-dev-Store Logo Mobile" class="visible-xs" width="80px" height="auto">
                
            </a><!-- navbar-brand home Finish -->
            
            <button class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                
                <span class="sr-only">Toggle Navigation</span>
                
                <i class="fa fa-align-justify"></i>
                
            </button>
            
            <button class="navbar-toggle" data-toggle="collapse" data-target="#search">
                
                <span class="sr-only">Toggle Search</span>
                
                <i class="fa fa-search"></i>
                
            </button>
            
        </div><!-- navbar-header Finish -->
           
           <div class="navbar-collapse collapse" id="navigation"><!-- navbar-collapse collapse Begin -->
               
               <div class="padding-nav"><!-- padding-nav Begin -->
                   
                   <ul class="nav navbar-nav left"><!-- nav navbar-nav left Begin -->
                       
                        <li class="<?php if($active=='home') echo 'active';?>">
                           <a href="../index.php">Trang Chủ</a>
                       </li>
                       <li class="<?php if($active=='shop') echo 'active';?>">
                           <a href="../shop.php">Cửa Hàng</a>
                       </li>
                       <li class="<?php if($active=='account') echo 'active';?>">
                            <a href="my_account.php">Tài Khoản</a>
                        </li>
                        <li class="<?php if($active=='cart') echo 'active';?>">
                           <a href="../cart.php">Mua Hàng</a>
                       </li>
                       <li class="<?php if($active=='contact') echo 'active';?>">
                           <a href="../contact.php">Liên hệ chúng tôi</a>
                       </li>
                       
                   </ul><!-- nav navbar-nav left Finish -->
                   
               </div><!-- padding-nav Finish -->
               
               <a href="../cart.php" class="btn navbar-btn btn-primary right"><!-- btn navbar-btn btn-primary Begin -->
                   
                    <i class="fa fa-shopping-cart"></i>
                   
                   <span><?php item();?> Sản phẩm trong giỏ hàng</span>
                   
               </a><!-- btn navbar-btn btn-primary Finish -->
               
               <div class="navbar-collapse collapse right"><!-- navbar-collapse collapse right Begin -->
                   
                   <button class="btn btn-primary navbar-btn" type="button" data-toggle="collapse" data-target="#search"><!-- btn btn-primary navbar-btn Begin -->
                       
                       <span class="sr-only">Toggle Search</span>
                       
                       <i class='bx bx-search' style="font-size: 20px;"></i>
                       
                   </button><!-- btn btn-primary navbar-btn Finish -->
                   
               </div><!-- navbar-collapse collapse right Finish -->
               
               <div class="collapse clearfix" id="search"><!-- collapse clearfix Begin -->
                   
                   <form method="get" action="results.php" class="navbar-form"><!-- navbar-form Begin -->
                       
                       <div class="input-group"><!-- input-group Begin -->
                           
                           <input type="text" class="form-control" placeholder="Search" name="user_query" required>
                           
                           <span class="input-group-btn"><!-- input-group-btn Begin -->
                           
                           <button type="submit" name="search" value="Search" class="btn btn-primary"><!-- btn btn-primary Begin -->
                               
                               <i class="fa fa-search"></i>
                               
                           </button><!-- btn btn-primary Finish -->
                           
                           </span><!-- input-group-btn Finish -->
                           
                       </div><!-- input-group Finish -->
                       
                   </form><!-- navbar-form Finish -->
                   
               </div><!-- collapse clearfix Finish -->
               
           </div><!-- navbar-collapse collapse Finish -->
           
       </div><!-- container Finish -->
       
   </div><!-- navbar navbar-default Finish -->

   <div id="content"><!-- content begin -->
       <div class="container"><!-- container begin -->
           <div class="col-sm-12"><!--col-md-12  begin -->
                <ul class="breadcrumb"><!-- breadcrumb begin -->
                    <li>
                        <a href="index.php">Trang Chủ</a>
                    </li>
                    <li>
                        Tài Khoản
                    </li>
                </ul>
           </div><!-- col-md-12  Finish -->
           <div class="col-md-3"> <!-- col-md-3 begin -->            
            <?php
                include("includes/sidebar.php");
            ?>
           </div><!-- col-md-3 finish -->
           <div class="col-md-9">
               <div class="box">
              
                  <h1 align="center"> Chi Tiết Đơn Hàng </h1>
                  <form action="confirm.php?update_id=<?php echo $order_id;?>" method= "post" enctype="multipart/form-data">
                   <?php
                    $customer_session = $_SESSION['customer_email'];
                    
                    $get_customer = "select * from customers where customer_email = '$customer_session'";

                    $run_customer = mysqli_query($con,$get_customer);

                    $row_customer = mysqli_fetch_array($run_customer);

                    $customer_id = $row_customer['customer_id'];

                    $get_orders = "select * from orders where customer_id = '$customer_id'";

                    $run_orders  = mysqli_query($con,$get_orders);

                    $i = 0;

                    while($row_orders = mysqli_fetch_array($run_orders)){
                        
                        $order_id = $row_orders['order_id'];

                        $total_order = $row_orders['total_order'];

                        $invoice_no = $row_orders['invoice_no'];

                        $order_date = substr($row_orders['order_date'],0,11);

                        $order_status = $row_orders['order_status'];

                        $i++;

                        if ($order_status == '0') {
                            $order_status = 'Chờ xác nhận';
                        }
                        else if($order_status=='1'){
                            $order_status = 'Đang giao hàng';
                        }
                        else{
                            $order_status = 'Giao thành công';
                        }
                    }
                ?>
                      <div class="form-group">
                        <label> Mã Hóa Đơn: </label>
                        <input type="text" class="form-control" name="invoice_no" value="<?php echo $order_id;?>" required>
                      </div>
                      <div class="form-group">
                        <label> Tổng Tiền: </label>
                        <input type="text" class="form-control" name="amount_sent"  value="<?php echo number_format($total_order, 0, ',', '.') . "đ";?>" required>
                      </div>
                      <div class="form-group">
                        <label> Ngày Đặt Hàng: </label>
                        <input type="text" class="form-control" name="date" value="<?php echo $order_date?>" required>
                      </div>
                      <div class="form-group">
                        <label> Trạng Thái: </label>
                        <input type="text" class="form-control" name="status" value="<?php echo $order_status?>" required>
                      </div>
                      <table class="table table-bordered table-hover">
                                <head>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên sản phẩm</th>
                                        <th>Số lượng</th>
                                        <th>Giá</th>
                                        <th>Kích Thước</th>
                                        <th>Tổng Tiền</th>
                                    </tr>
                                </head>
                                <tbody>
                                    <?php
                                    $order_detail_array = mysqli_query($con, "select * from order_detail where order_id = $order_id");
                                    $i = 0;
                                    while ($row = mysqli_fetch_array($order_detail_array)) {
                                        $pro_size = $row['size'];
                                        $pro_id = $row["product_id"];
                                        $result = mysqli_query($con, "select product_title, product_price from product where product_id = '$pro_id'");
                                        $product = mysqli_fetch_assoc($result);
                                        $pro_name = $product['product_title'];
                                        $pro_price = $product['product_price'];
                                        
                                        $pro_price_format = number_format($pro_price, 0, ',', '.') . "đ";
                                        $quantity = $row["quantity"];
                                        $total = $quantity * $pro_price;
                                        $total_format = number_format($total, 0, ',', '.') . "đ";
                                        $i++;
                                    ?>
                                        <tr>
                                            <td><?php echo $i; ?> </td>
                                            <td> <?php echo $pro_name; ?> </td>
                                            <td> <?php echo $quantity; ?> </td>
                                            <td> <?php echo $pro_price_format; ?></td>
                                            <td> <?php echo $pro_size;?></td>
                                            <td> <?php echo $total_format; ?> </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                      <div class="text-center">
                          <button class="btn btn-primary btn-lg" name="confirm_payment">
                                <a href="http://localhost/KLTN/NamFashion/customer/my_account.php?my_orders" style="color: #fff;"><i class="fa fa-user-md"></i> Quay lại</a>
                          </button>
                      </div>
                 
                  </form>
                  <?php
                    if(isset($_POST['confirm_payment']))
                    {
                        $update_id = $_GET['update_id'];

                        $invoice_no = $_POST['invoice_no'];

                        $amount = $_POST['amount_sent'];

                        $payment_mode = $_POST['payment_mode'];

                        $payment_code = $_POST['code'];

                        $payment_date = $_POST['date'];

                        $complete = "Complete";

                        $insert_payment = "insert into payments (invoice_no,amount,payment_mode,payment_code,payment_date) values ('$invoice_no','$amount','$payment_mode','$payment_code','$payment_date')";

                        $run_payment = mysqli_query($con,$insert_payment);

                        $update_customer_order = "update customer_orders set order_status ='$complete' where order_id = '$update_id'";

                        $run_customer_order =  mysqli_query($con,$update_customer_order);

                        $update_pending_order = "update pending_orders set order_status = '$complete' where order_id = '$update_id'";

                        $run_pending_order = mysqli_query($con,$update_pending_order);

                        if($run_pending_order)
                        {
                            echo "<script>alert('Cảm ơn bạn đã mua hàng. Đơn hàng của bạn sẽ được hoàn thành trong 24 giờ')</script>";

                            echo "<script>window.open('my_account.php?my_orders','_self')</script>";
                        }

                    }
                  ?>
               </div>
           </div>
           
       </div><!-- container Finish -->

   </div><!-- content Finish -->

   <?php
        include("includes/footer.php");
    ?>
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
</body>
</html>

<?php
    }
?>