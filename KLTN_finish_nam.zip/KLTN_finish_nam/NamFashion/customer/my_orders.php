<center>
    <h1>
        Đơn Hàng 
    </h1>
    <p class="lead">
        Các đơn hàng ở cùng một nơi
    </p>
    <p class="text-muted">
        Nếu bạn có bất kì câu hỏi nào hãy <a href="../contact.php">Liên hệ chúng tôi</a>.Dịch vụ chăm sóc khách hàng của chúng tôi làm việc <strong>24/7</strong> 
    </p>
</center>
<hr>
<div class="table-reponsive">
    <table class="table table-bordered table-hover">
        <head>
            <tr>
                <th>STT</th>
                <th>Mã hóa đơn:</th>
                <th>Tổng Tiền</th>
                <th>Ngày đặt hàng:</th>
                <th>Trạng thái:</th>
            </tr>
        </head>
        <tbody>
            <?php
            $customer_session = $_SESSION['customer_email'];
            $get_customer = "select * from customers where customer_email = '$customer_session'";
            $run_customer = mysqli_query($con, $get_customer);
            $row_customer = mysqli_fetch_array($run_customer);
            $customer_id = $row_customer['customer_id'];
            $get_orders = "select * from orders where customer_id = '$customer_id'";
            $run_orders  = mysqli_query($con, $get_orders);
            $i = 0;
            while ($row_orders = mysqli_fetch_array($run_orders)) {
                $order_id = $row_orders['order_id'];
                $total_order = $row_orders["total_order"];
                $order_date = substr($row_orders['order_date'], 0, 11);
                $order_status = $row_orders['order_status'];
                $i++;
                if ($order_status == '0') {
                    $order_status = 'Chờ xác nhận';
                }
                else if($order_status=='1'){
                    $order_status = 'Đang giao hàng';
                }
                else{
                    $order_status = 'Giao thành công';
                }
            ?>
                <tr>
                    <th><?php echo $i; ?> </th>
                    <td> <?php echo $order_id; ?> </td>
                    <td><?php echo $total_order; ?></td>
                    <td> <?php echo $order_date; ?> </td>
                    <td> <?php echo $order_status; ?> </td>
                    <td>
                        <a href="confirm.php?order_id=<?php echo $order_id; ?>" target="_blank" class="btn btn-primary btn-sm"> Xem </a>
                    </td>
                    <td>
                        <a href="delete_order.php?order_id=<?php echo $order_id; ?>" target="_blank" class="btn btn-primary btn-sm"> Hủy </a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>