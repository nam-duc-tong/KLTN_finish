<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu begin -->
    <div class="panel-heading"><!--panel-heading  begin -->
        <!-- <center>
            <img src="customer_image/125207426_4699151893489138_8389512900406846996_o.jpg" alt="My Profile" width="200px" height="auto">
        </center>
        <br>
        <h3 align="center" class="panel-title">
            Name: Tong Duc Nam
        </h3> -->
    <?php
        $customer_email = $_SESSION['customer_email'];
        
        $get_customer = "select * from customers where customer_email = '$customer_email'";

        $run_customer = mysqli_query($con,$get_customer);

        $row_customer = mysqli_fetch_array($run_customer);

        $customer_image = $row_customer['customer_image'];

        $customer_email = $row_customer['customer_email'];

        if(!isset($_SESSION['customer_email']))
        {
            
        }
        else{
            echo "
                <center>
                    <img src='customer_image/$customer_image' class='img-responsive'>
                </center>
                <br/>
                <h3 class='panel-title' align='center'>
                    Email: $customer_email
                </h3>
            ";
        }
    ?>


    </div>
    <div class="panel-body">
        <div class="nav-pills nav-stacked nav">
            <li class="<?php if(isset($_GET['my_orders'])){echo "active";}?>">
                <a href="my_account.php?my_orders">
                    <i class="fa fa-list"></i> Đơn Hàng
                </a>
            </li>
            <li class="<?php if(isset($_GET['pay_offline'])){echo "active";}?>">
                <a href="my_account.php?pay_offline">
                    <i class="fa fa-bolt"></i> Thanh Toán Trực Tiếp
                </a>
            </li>
            <li class="<?php if(isset($_GET['change_pass'])){echo "active";}?>">
                <a href="my_account.php?change_pass">
                    <i class="fa fa-user"></i> Thay Đổi Mật Khẩu
                </a>
            </li>
            <li class="<?php if(isset($_GET['edit_account'])){echo "active";}?>">
                <a href="my_account.php?edit_account">
                    <i class="fa fa-pencil"></i> Chỉnh Sửa Tài Khoản
                </a>
            </li>
            <li class="<?php if(isset($_GET['delete_account'])){echo "active";}?>">
                <a href="my_account.php?delete_account">
                    <i class="fa fa-trash-o"></i> Xóa Tài Khoản
                </a>
            </li>
            <li>
                <a href="logout.php">
                    <i class="fa fa-sign-out"></i> Đăng Xuất
                </a>
            </li>
        </div>
    </div>
</div>