<?php
    session_start();
    $active='account';
    
    if(!isset($_SESSION['customer_email']))
    {
        echo "
            <script>window.open('../checkout.php','_self')</script>
        ";
    }
    else
    {
        include('includes/db.php');
        include('functions/functions.php');

        if(isset($_GET['order_id']))
        {
            $order_id = $_GET['order_id'];
        }
            mysqli_query($con,"Delete from orders where order_id = $order_id");
            header('Location: my_account.php?my_orders');
    }
?>
