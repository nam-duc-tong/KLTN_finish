<h1 align="center">Thay Đổi Mật Khẩu</h1>

<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        
        <label> Mật Khẩu Cũ: </label>

        <input type="password" name="old_pass" class="form-control" required>

    </div>
    <div class="form-group">
        
        <label> Mật Khẩu Mới: </label>

        <input type="password" name="new_pass" class="form-control" required>
        
    </div>

    <div class="form-group">
        
        <label> Xác Nhận Mật Khẩu Mới: </label>

        <input type="password" name="new_pass_again" class="form-control" required>
        
    </div>
    

    <div class="text-center">

        <button class="btn btn-primary" name="submit" type="submit">

            <i class="fa fa-user-md"></i> Cập Nhật

        </button>

    </div>
    
</form>

<?php
    if(isset($_POST['submit']))
    {
        $c_email = $_SESSION['customer_email'];

        $c_old_pass = $_POST['old_pass'];

        $c_new_pass = $_POST['new_pass'];

        $c_new_pass_again = $_POST['new_pass_again'];

        $sel_old_pass = "select * from customers where customer_pass='$c_old_pass'";

        $run_c_old_pass = mysqli_query($con,$sel_old_pass);

        $check_c_old_pass = mysqli_fetch_array($run_c_old_pass);

        if($check_c_old_pass==0)
        {
            echo "<script>alert('Xin lỗi, mật khẩu hiện tại của bạn không đúng. Hãy Thử lại')</script>";
            
            exit();
        }

        if($c_new_pass!=$c_new_pass_again)
        {
            echo "<script>alert('')</script>";

            exit();
        }
        
        $update_c_pass = "update customers set customer_pass='$c_new_pass' where customer_email='$c_email'";

        $run_c_pass = mysqli_query($con,$update_c_pass);

        if($run_c_pass){

            echo "<script>alert('Mật khẩu của bạn đã được cập nhật')</script>";

            echo "<script>window.open('my_account.php?my_orders','_self')</script>";
        }

    }
?>