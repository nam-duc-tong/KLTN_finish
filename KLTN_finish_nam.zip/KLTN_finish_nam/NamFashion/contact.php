<?php
    $active='contact';
    include('includes/header.php');
?>

   <div id="content"><!-- content begin -->
       <div class="container"><!-- container begin -->
           <div class="col-sm-12"><!--col-md-12  begin -->
                <ul class="breadcrumb" style=" background-color: #fff;"><!-- breadcrumb begin -->
                    <li>
                        <a href="index.php">Trang Chủ</a>
                    </li>
                    <li>
                        Liên Hệ
                    </li>
                </ul>
           </div><!-- col-md-12  Finish -->
           <div class="col-md-3"> <!-- col-md-3 begin -->            
            <?php
                include("includes/sidebar.php");
            ?>
           </div><!-- col-md-3 finish -->
        <div class="col-md-9"> <!-- col-md-9 begin --> 
            <div class="box">

                <div class="box-header">
                    <center>
                        <h2>Liên Hệ Với Chúng Tôi</h2>
                        <p class="text-muted">
                            Nếu bạn có thăc mắc gì hãy liên hệ với chúng tôi. Chúng tôi sẽ phải hồi lại sau
                        </p>
                    </center>
                    <form action="contact.php" method="post">
                        <div class="form-group">
                            <label>Họ Tên</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Số Điện Thoại</label>
                            <input type="number" class="form-control" name="subject" required>
                        </div>
                        <div class="form-group">
                            <label>Thông Điệp</label>
                            <textarea name="message" class="form-control"></textarea>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" name="submit">
                                <i class="fa fa-user-md"></i>   Gửi
                            </button>
                        </div>
                    </form>
                    <?php
                        if(isset($_POST['submit']))
                        {
                            $sender_name = $_POST['name'];

                            $sender_email = $_POST['email'];

                            $sender_subject = $_POST['subject'];

                            $sender_message = $_POST['message'];

                            $receiver_email = "nam2382000@gmail.com";

                            mail($receiver_email,$sender_name,$sender_subject,$sender_message,$sender_email);
                            
                            $email = $_POST['email'];

                            $subject = "Welcome to my website";

                            $msg = "Thank for sending us message. ASAP We will reply your message";
                            
                            $from = "nam2382000@gmail.com";

                            mail($email,$subject,$msg,$from);

                            echo "<h2> Your message has sent successfully</h2>";
                            
                        }
                    ?>
                </div>
            </div>
        </div> <!-- col-md-9 finish --> 
       </div><!-- container Finish -->

</div><!-- content Finish -->

<?php
     include("includes/footer.php");
 ?>
 <script src="js/jquery-331.min.js"></script>
 <script src="js/bootstrap-337.min.js"></script>
</body>
</html>