<?php
    if(!isset($_SESSION['admin_email']))
    {
        echo "<script>window.open('login.php','_self')</script>";
    }
    else{
?>
<div class="row"style="padding-top: 50px;">
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> Bảng điều khiển / Đơn hàng
            </li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <i class="fa fa-tags"></i> Đơn Hàng
                </h3>
            </div>

            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                              <th> STT: </th>
                              <th> Mã hóa đơn: </th>
                              <th> Ngày đặt hàng </th>
                              <th> Tổng tiền:  </th>
                              <th> Khách hàng</th>
                              <th> Trạng thái: </th>
                              <!-- <th> Xóa: </th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                                $i = 0;
                                
                                $get_orders = "select * from orders";

                                $run_orders = mysqli_query($con,$get_orders);

                                while($row_orders = mysqli_fetch_array($run_orders))

                                {
                                    $order_id = $row_orders['order_id'];

                                    $c_id = $row_orders['customer_id'];

                             

                                    $total_order = $row_orders['total_order'];

                                    $total_order_format = number_format($total_order, 0, ',', '.') . "đ";

                                    $order_status = $row_orders['order_status'];

                                    $order_date = $row_orders['order_date'];

                                    $order_status = $row_orders['order_status'];

                                    $get_customer = "select * from customers where customer_id ='$c_id'";

                                    $run_customer = mysqli_query($con,$get_customer);

                                    $row_customer = mysqli_fetch_array($run_customer);

                                    $customer_email = $row_customer['customer_email'];

                                    $customer_name = $row_customer['customer_name'];

                                    if ($order_status == '0') {
                                        $order_status = 'Chờ xác nhận';
                                    }
                                    else if($order_status=='1'){
                                        $order_status = 'Đang giao hàng';
                                    }
                                    else{
                                        $order_status = 'Giao thành công';
                                    }
                                    $i++;
                            ?>
                            <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $order_id;?></td>
                                <td><?php echo $order_date;?></td>
                                <td><?php echo $total_order_format;?></td>
                                <td><?php echo $customer_name;?></td>
                                <td><?php echo $order_status;?></td>
                                <td>
                                    <button type="button" class="btn btn-primary"><a href="index.php?view_order_detail=<?php echo $order_id;?>" style="color: #fff; text-decoration: none;">Chi tiết</a></button>
                                </td>
                                <td>
                                   <button type="button" class="btn btn-primary">Xác nhận đơn</button>
                                </td>
                                <td>
                                 
                                    <button type="button" class="btn btn-danger">Hủy đơn</button>
                                </td>
                              

                            </tr>
                            <?php
                                }   
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
    }
?>