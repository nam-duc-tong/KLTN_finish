<?php
    if(!isset($_SESSION['admin_email']))
    {
        echo "<script>window.open('login.php','_self')</script>";
    }
    else{
?>

<?php
    if(isset($_GET['edit_slider']))
    {
        $edit_slider_id = $_GET['edit_slider'];

        $edit_slider = "select * from slider where slider_id ='$edit_slider_id'";

        $run_edit_slider = mysqli_query($con,$edit_slider);

        $row_edit_slider = mysqli_fetch_array($run_edit_slider);

        $slider_id = $row_edit_slider['slider_id'];

        $slider_name = $row_edit_slider['slider_name'];

        $slider_url = $row_edit_slider['slider_url'];

        $slider_image = $row_edit_slider['slider_image'];
    }
?>

<div class="row" style="padding-top: 50px;">
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li>

                <i class="fa fa-dashboard"></i> Bảng thống kê / Chỉnh sửa slide

            </li>
        </ol>
    </div>
</div>

<div class="row">

    <div class="col-lg-12">

        <div class="panel panel-default">

            <div class="panel-heading">

                <h3 class="panel-title">

                    <i class="fa fa-money fa-fw"></i> Chỉnh sửa slide

                </h3>

            </div>

            <div class="panel-body">

                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        
                        <label for="" class="control-label col-md-3">

                            Tên slide

                        </label>

                        <div class="col-md-6">

                            <input type="text" name="slider_name" class="form-control" value="<?php echo $slider_name;?>">

                        </div>
                
                    </div>

                    <div class="form-group">
                        
                        <label for="" class="control-label col-md-3">

                            Slide Url

                        </label>

                        <div class="col-md-6">

                            <input type="text" name="slider_url" class="form-control" value="<?php echo $slider_url;?>">

                        </div>
                
                    </div>

                    <div class="form-group">


                        <label for="" class="control-label col-md-3">

                            Ảnh slide

                        </label>

                            <div class="col-md-6">
                             
                                <input type="file" name= "slider_image" class="form-control"></input>
                                <br>
                                <img src="slides_images/<?php echo $slider_image; ?>" alt="" class="img-responsive">
                         
                            </div>

                    </div>
                    
                    <div class="form-group">
                        <label for="" class="control-label col-md-3">

                        </label>
                        <div class="col-md-6">
                        <input type="submit" name="update" value="Cập nhật" class="btn btn-primary form-control">
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>

<?php
    if(isset($_POST['update']))
    {
        $slider_name = $_POST['slider_name'];

        $slider_url = $_POST['slider_url'];

        $slider_image = $_FILES['slider_image']['name'];

        $temp_name = $_FILES['slider_image']['tmp_name'];

        move_uploaded_file($temp_name,"slides_images/$slider_image");

        $update_slider = "update slider set slider_name = '$slider_name',slider_image = '$slider_image',slider_url = '$slider_url' where slider_id = '$edit_slider_id'";

        $run_update_slider = mysqli_query($con,$update_slider);

        if($run_update_slider)
        {
            echo "<script>alert('Slider của bạn đã được cập nhật thành công!!!')</script>";
            echo "<script>window.open('index.php?view_slides','_self')</script>";
        }
    }
?>

<?php
    }
?>