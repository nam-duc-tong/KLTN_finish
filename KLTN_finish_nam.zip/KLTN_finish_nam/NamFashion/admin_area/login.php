<?php
    session_start();
    include("includes/db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cửa Hàng Nam Fashion</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="font-awsome/css/style.css">
    <link rel="stylesheet" href="font-awsome/css/login.css">
    <!-- <link rel="stylesheet" href="styles/shop.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <div class="container">
        <form action="" class="form-login" method = "post">
            <h2 class="form-login-heading">
                Đăng nhập Admin
            </h2>
            <input type="text" class="form-control" placeholder="Nhập vào Email" name = "admin_email" required>
            
            <input type="password" class="form-control" placeholder="Nhập vào mật khẩu" name = "admin_pass" required>
            
            <button type="submit" class="btn btn-tg btn-primary btn-block" name="admin_login">
                Đăng nhập
            </button>
        </form>
    </div>
</body>
<?php
    if(isset($_POST['admin_login'])){

        $admin_email = mysqli_real_escape_string($con,$_POST['admin_email']);
        
        $admin_pass = mysqli_real_escape_string($con,$_POST['admin_pass']);

        //mysqli_real_escape_string : là hàm loại bỏ các ký tự đặc biệt trong một chuỗi để sử dụng truy vấn sql

        $get_admin = "select * from admins where admin_email = '$admin_email' and admin_pass = '$admin_pass'";

        $run_admin = mysqli_query($con,$get_admin);

        $count = mysqli_num_rows($run_admin);

        if($count==1)
        {
            $_SESSION['admin_email'] = $admin_email;
            $_SESSION['admin_pass'] = $admin_pass;
            echo "<script>alert('Đăng nhập thành công')</script>";
            echo "<script>window.open('index.php?dashboard','_self')</script>";
        }
        else{
            echo "<script>alert('email hoặc mật khẩu không chính xác!')</script>";
        }
    }
?>