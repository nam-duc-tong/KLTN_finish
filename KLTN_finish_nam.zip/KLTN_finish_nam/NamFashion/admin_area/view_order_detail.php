<?php
    if(!isset($_SESSION['admin_email']))
    {
        echo "<script>window.open('login.php','_self')</script>";
    }
    else{
        if(isset($_GET['view_order_detail']))
        {
            $order_id = $_GET['view_order_detail'];
?>
<div class="row"style="padding-top: 50px;">
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> Bảng điều khiển / Chi Tiết Đơn hàng
            </li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <i class="fa fa-tags"></i> Chi Tiết Đơn Hàng
                </h3>
            </div>

            <div class="panel-body">
                <div class="table-responsive">
                <h3>Mã đơn hàng: <?php echo $order_id;?></h3>
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                              <th> STT: </th>
                              <th> Tên Sản Phẩm: </th>
                              <th> Số Lượng: </th>
                              <th> Giá tiền:  </th>
                              <th> Kích cỡ: </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            

                                $i = 0;
                                
                                $get_orders = "select * from order_detail where order_id = $order_id";

                                $run_orders = mysqli_query($con,$get_orders);

                                while($row_orders = mysqli_fetch_array($run_orders))

                                {

                                    $product_id = $row_orders['product_id'];

                                    $size = $row_orders['size'];

                                    $quantity = $row_orders['quantity'];


                                    $get_products = "select * from product where product_id='$product_id'";

                                    $run_products = mysqli_query($con,$get_products);

                                    $row_products = mysqli_fetch_array($run_products);

                                    $product_title = $row_products['product_title'];

                                    $pro_price = $row_products['product_price'];

                                    $pro_price_format  =  number_format($pro_price, 0, ',', '.') . "đ";

                                    $i++;
                            ?>
                            
                            <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $product_title;?></td>
                                <td><?php echo $quantity;?></td>
                                <td><?php echo $pro_price_format;?></td>
                                <td><?php echo $size;?></td>
                            
                            </tr>
                            <?php
                                }   
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
    }               
}
?>